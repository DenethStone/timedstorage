<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
  <link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
	<link rel="stylesheet" href="styl.css" type="text/css" />
	<title>Vyhláška 50 / 1978 Sb.</title>
   	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<header>
		<div id="logo">
				<la>Vyhláška 50/1978 Sb.</la>
				<lb>  Zkušební testy §5</lb>
		</div>
		<nav>
        </nav>
        <div id="pravy">
            <?
                echo "Spuštěno: ".date("H:i - d.m.Y");
            ?>
		</div>
</header>
<center>
<article align="left">
<br><br><br>
<p align="left">
<center><h1>Online test - vyhláška 50/§5</h1></center>
	<form action="vyhlaska.php" method=GET>
		<FIELDSET><LEGEND><b>Varianta testu</b></LEGEND>
		    <input type=radio name="otazky" value="10">10 otázek<br>
		    <input type=radio name="otazky" value="15">15 otázek<br>
		    <input type=radio name="otazky" value="20">20 otázek<br>
            <input type=radio name="otazky" value="40">40 otázek<br>
            <input type=radio name="otazky" value="60">60 otázek<br>
            <input type=radio name="otazky" value="80">80 otázek<br>
		    <input type=radio name="otazky" value="124">Celý test<br>
            <DIV class=buttonek align="center">
	            <BUTTON type=SUBMIT class="button button2">START</BUTTON>
            </DIV>
		</FIELDSET><BR>
	</form>

    <p>Vítej příteli elektřiny!</p>
    <p>S největší pravděpodobností jsi tento web navštívil, aby sis ověřil své znalosti vyhlášky 50. Ať už proto, že se připravuješ na zkoušku nebo si chceš pouze osvěžit znalosti,
na této stránce najdeš testy, které ti pomohou.</p>
    <p class="data">Před tím, než se pustíš do prověřování svých znalostí, věnuj prosím pozornost videím, která jsou za účelem výuky vyhlášky 50 vytvořena a dostupná na stránkách <a href="https://elektrika.tv/video/2018/spustili_jsme_nataceni_v50.mp4" target="_blank">www.elektrika.tv</a>.</p>
    <p>Přeji hodně štěstí a úspěchu jak při skládání zkoušek, tak i v profesním životě.</p><br>
    Josef Němec
    <center><h2><b><p class="data">Chceš si vyzkoušet i jiné testy vyhlášky 50? Pokud ano, zkus to na <a href="https://e-revize.cz/testy/index" target="_blank">e-revize.cz</a></p></b></h2></center><br><br>
    </p>
    <br>
</article>
<footer align="center"><br><br>Frontend and backend &copy;Josef Němec 2020</footer>
</center>
</body>
</html>