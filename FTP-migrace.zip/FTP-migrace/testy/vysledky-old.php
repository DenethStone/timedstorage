<html>
<HEAD>
	<title>Test 50 - Výsledky</title>
	<meta charset="UTF-8">
	<style type="text/css"><!--
		body { background-image: URL('./images/w2.jpg');
			   background-attachment: fixed; } 
		FIELDSET { padding: 8px; }
		LEGEND { color: black;
				 padding-bottom: 6px; }
		.text { position: absolute;
				left: 120px; }
		.button { text-align: center;
				  margin: 8px; }
	</style>
</HEAD>
<body>
	<center><H1>Výsledky testu</H1></center>
	<HR>
	
	<?
			//$OtazkyMAX=$_GET["pocet"];
			/*echo "<br>".$pocet."<br>";
			$fp = FOpen("otazky.dat", "r");
				$OtazkyMAX = fread($fp, filesize("otazky.dat"));
			FClose($fp);*/
			$OtazkyMAX=60;
			$t_start=strtotime($_GET["cas"]);
			$t_stop=strtotime(date("H:i"));

			$jmeno=$_GET["name"];
			echo "Start: ".date("H:i - d.m.Y", $t_start)." - Stop: ".date("H:i - d.m.Y", $t_stop)."<br>";
			echo "Rozdíl: ".(($t_stop-$t_start)/60)."<br>";
			echo "Jméno a příjmení: ".$jmeno."<br>";
			echo "IP: ".$_SERVER["REMOTE_ADDR"]."<br>";
			echo "Browser: ".$_SERVER["HTTP_USER_AGENT"]."<br>";
			echo "Otázky a odpovědi: <br>\n";
			
			$odpoved=0;
			for ($i=0, $n=0; $i < $OtazkyMAX; $i++) {
				$ziskanyget = $_GET["Odpoved".$i];
				echo "Odpoved".$i."=".$ziskanyget."&";
				list($uspel, $otazka) = Explode(".",$ziskanyget);
				if ($ziskanyget==""||$uspel==0) {
					$chyby[$n]=$otazka;		
					$n++;
				}
				if ($ziskanyget=="") $odpoved++; 
			}

			$spravne=Count($chyby);
			echo "<br>Počet bodů: ".(60-$spravne);

			echo "<center><font color=\"red\" size=\"5\"><b>";
			if ($odpoved==0) {
				if ($spravne>10) {
					echo "Nebyl to asi tipsport, ale doporučuji si to celé projít znovu...<br>";
				} else if (($spravne <= 10)&&($spravne > 5)) {
					echo "Není to zlé, ale ".$spravne." je pořád dost chyb na to, aby jsi uspěl...<br>";
				} else if (($spravne <= 5)&&($spravne > 2)) { 
					echo "Krásná práce, mohlo by to být i lepší, ale i tak - gratuluji ;) <br>";
				} else {
					echo "Výborně! Mám z tebe radost pane elektrikáři :) <br>";
				}
				echo "</b></font></center><br><hr>";
				echo "<FIELDSET><LEGEND><b><font color=\"blue\">Počet správných odpovědí: ".($OtazkyMAX-Count($chyby))." z ".$OtazkyMAX." </b></LEGEND>";
			} else echo "<FIELDSET><LEGEND><b><font color=\"blue\">Nevyplnil jsi ".$odpoved." otázek... Zkus to znovu, ať mám co opravovat... </b></LEGEND>";
			if(Count($chyby)!=0 && $odpoved==0) {
				$spojeni = new mysqli("wm149.wedos.net", "w168935_enotes", "vYhl4ska#", "d168935_enotes");
				if ($spojeni->connect_errno) {
		    		echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
            		exit();
        		}
        		mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady

				for ($i=0; $i<Count($chyby); $i++) {
					//echo $chyby[$i]."<br>";
					$d_zadani = "SELECT * FROM otazky WHERE ID=$chyby[$i]";
            		$d_odpoved = "SELECT * FROM odpovedi WHERE ID=$chyby[$i]";
            		$vysledek = $spojeni->query($d_zadani);
					$vypis = mysqli_fetch_assoc($vysledek);
					echo "<FIELDSET><LEGEND><b>".$vypis["Zadani"]."</b></LEGEND>\n";
					if ($vypis["Image"]=="1") echo "<img src=\"./images/img".$chyby[$i].".png\" align=\"right\">";
					$vysledek->free();
					$vysledek = $spojeni->query($d_odpoved);
            		$vypis = mysqli_fetch_assoc($vysledek);
					if ($vypis["Image"]=="1") echo "<img src=\"./images/".$vypis["odpoved1"]."\"><br>\n";
					else echo "<font color=\"red\">".$vypis["odpoved1"]."<br>\n";
					echo "</FIELDSET><BR>";
					$vysledek->free();
				}
				$spojeni->close();
			}
			
			$fp = FOpen ("refscore.dat", "a");
	        FWrite ($fp, $_SERVER["REMOTE_ADDR"]." : ".$spravne."\n");
			FClose ($fp);
	?>		
	</FIELDSET><br>
        <center><h1><b><a href="http://elektro-notes.cz/testy/start.php">Zpět na úvodní stránku</a><b></h1></center><br>
	<center><font size="2" color="black">Vytvořil: Josef Němec (c)2017. Revidováno - únor 2021</font></center><br>
</body>
</html>
	