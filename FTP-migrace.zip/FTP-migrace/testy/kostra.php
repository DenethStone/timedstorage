<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
  <link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
	<link rel="stylesheet" href="styl.css" type="text/css" />
	<title>Vyhláška 50 / 1978 Sb.</title>
   	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<header>
		<div id="logo">
				<la>Vyhláška 50/1978 Sb.</la>
				<lb>SOŠ a SOU Lanškroun</lb>
		</div>
		<nav>
            <ul>
                <li>
                    <?php
                        echo " Připojen z IP: ".$_SERVER["REMOTE_ADDR"];
                    ?>
                </li>
            </ul>
        </nav>
        <div id="pravy">
            <?php
                echo "Odesláno: ".date("H:i - d.m.Y");
                
            ?>
		</div>
</header>
<center>
<article align="left">
<br><br><br>
<p align="left">

</p>
<br>
</article>
<footer align="center"><br><br>Frontend and backend &copy;Josef Němec 2020</footer>
</center>
</body>
</html>