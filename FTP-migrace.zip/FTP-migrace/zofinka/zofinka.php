<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
  <link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
	<link rel="stylesheet" href="zofinka2.css" type="text/css" />
	<title>IoT meteostanice Žofinka</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="refresh" content="300">
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	
	<script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Rok', 'Teplota ve °C'],
            <?
                $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
                if ($spojeni->connect_errno) {
                    echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
                    exit();
                }

         	    mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
         	    $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));
                
                for($id=$pocet-96; $id<$pocet+1; $id++){
            	    $d_zadani = "SELECT * FROM Teplota WHERE id=".$id;
            	    $vysledek = $spojeni->query($d_zadani);
            	    $vypis = mysqli_fetch_assoc($vysledek);
            
                    if((int)$vypis["teplota"]!=-127) { 
                        echo "['".date("H:i", $vypis["cas"])."',".$vypis["teplota"]."]"; 
                        if($id!=$pocet) echo ",\n";
                    }
            	    $vysledek->free();
                }
                $spojeni->close();
            ?>
        ]);

        var options = {
          curveType: 'function',
          backgroundColor: {
            fill: '#FFFFFF',
            fillOpacity: 0
          },
          legend: { position: 'bottom', textStyle: { color: 'white' }},
		  vAxis: { textStyle: { color: 'white' }},
          hAxis: { textStyle: { color: 'white' }},
		  lineWidth: 3,
          colors: [ 'orange', '#d3362d', '#e7711b',
                   '#e49307', '#e49307', '#e2431e' ],
        };

        var chart = new google.visualization.LineChart(document.getElementById('grafik'));

        chart.draw(data, options);
      }
	</script>

<script type="text/javascript">
		google.charts.load('current', {'packages':['corechart']});
		google.charts.setOnLoadCallback(drawChart);
  
		function drawChart() {
		  var data = google.visualization.arrayToDataTable([
			['Rok', 'Vlhkost'],
			<?
                $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
                if ($spojeni->connect_errno) {
                    echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
                    exit();
                }

         	    mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
         	    $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));
                
                for($id=$pocet-96; $id<$pocet+1; $id++){
            	    $d_zadani = "SELECT * FROM Teplota WHERE id=".$id;
            	    $vysledek = $spojeni->query($d_zadani);
            	    $vypis = mysqli_fetch_assoc($vysledek);
            
                    if((int)$vypis["teplota"]!=-127) { 
                        echo "['".date("H:i", $vypis["cas"])."',".$vypis["vlhkost"]."]"; 
                        if($id!=$pocet) echo ",\n";
                    }
            	    $vysledek->free();
                }
                $spojeni->close();
            ?>
		  ]);
  
		  var options = {
			curveType: 'function',
			backgroundColor: {
			  fill: '#FFFFFF',
			  fillOpacity: 0
			},
			legend: { position: 'bottom', textStyle: { color: 'white' }},
			vAxis: { textStyle: { color: 'white' }},
			hAxis: { textStyle: { color: 'white' }},
			lineWidth: 3,
			colors: [ 'blueviolet', '#d3362d', '#e7711b',
					 '#e49307', '#e49307', '#e2431e' ],
		  };
  
		  var chart = new google.visualization.LineChart(document.getElementById('grafik2'));
  
		  chart.draw(data, options);
		}
	</script>
	
	<script type="text/javascript">
		google.charts.load('current', {'packages':['corechart']});
		google.charts.setOnLoadCallback(drawChart);
  
		function drawChart() {
		  var data = google.visualization.arrayToDataTable([
			['Rok', 'Tlak v hPa'],
			<?
                $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
                if ($spojeni->connect_errno) {
                    echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
                    exit();
                }

         	    mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
         	    $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));
                
                for($id=$pocet-96; $id<$pocet+1; $id++){
            	    $d_zadani = "SELECT * FROM Teplota WHERE id=".$id;
            	    $vysledek = $spojeni->query($d_zadani);
            	    $vypis = mysqli_fetch_assoc($vysledek);
            
                    if((int)$vypis["teplota"]!=-127) { 
                        echo "['".date("H:i", $vypis["cas"])."',".$vypis["tlak"]."]"; 
                        if($id!=$pocet) echo ",\n";
                    }
            	    $vysledek->free();
                }
                $spojeni->close();
            ?>
		  ]);
  
		  var options = {
			curveType: 'function',
			backgroundColor: {
			  fill: '#FFFFFF',
			  fillOpacity: 0
			},
			legend: { position: 'bottom', textStyle: { color: 'white' }},
			vAxis: { textStyle: { color: 'white' }},
			hAxis: { textStyle: { color: 'white' }},
			lineWidth: 3,
			colors: [ '#b9c246', '#d3362d', '#e7711b',
					 '#e49307', '#e49307', '#e2431e' ],
		  };
  
		  var chart = new google.visualization.LineChart(document.getElementById('grafik1'));
  
		  chart.draw(data, options);
		}
	</script>
</head>
<body>
<header>
		<div id="logo">
				<la>Meteostanice Žofka</la>
				<lb>Lanškroun - Žichlínské Předměstí</lb>
		</div>
		<nav>
				<ul>
					<li class="aktivni"><a href="#">Aktuálně</a></li>
          <li><a href="https://www.lanskroun.eu/" target="_blank">Lanškroun</a></li>
				</ul>
        </nav>
        <div id="pravy">
            <?
                $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
                if ($spojeni->connect_errno) {
                  echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
                  exit();
                }
            
                mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
                $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));
            
                $d_zadani = "SELECT * FROM Teplota WHERE id=".$pocet;
                $vysledek = $spojeni->query($d_zadani);
                $vypis = mysqli_fetch_assoc($vysledek);
                echo "Naměřeno: ".date("H:i - d.m.Y",  $vypis["cas"]);
                $spojeni->close();
            ?>
		</div>
</header>
<center>
<article>
<?
    $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
    if ($spojeni->connect_errno) {
      echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
      exit();
    }

    mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
    $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));

    $d_zadani = "SELECT * FROM Teplota WHERE id=".$pocet;
    $vysledek = $spojeni->query($d_zadani);
    $vypis = mysqli_fetch_assoc($vysledek);

    // Výpočet rosného bodu
    $h = (((log10($vypis["vlhkost"]))-2)/0.4343)+((17.62*$vypis["teplota"])/(243.12+$vypis["teplota"]));
    $rbod = (243.12 * $h)/(17.62 - $h);
    ///////////////////////////////////

    echo "<div id=\"teplota\" class=\"cedule\"><br>Aktuální teplota:<br><hodnota>".$vypis["teplota"]." °C</hodnota>\n";
    echo "<br><popis>Rosný bod: </popis><br><rbod>".round($rbod,2)." °C</rbod></div>\n";
    echo "<div id=\"cas\" class=\"cedule\"><br>Vlhkost vzduchu:<br><br><hodnota>".$vypis["vlhkost"]." %</hodnota></div>\n";
    //echo "<popis>".date("H:i", $vypis["cas"])."</popis></div>";
    echo "<div id=\"tlak\" class=\"cedule\"><br>Aktuální tlak:<br><hodnota>".$vypis["tlak"]." hPa</hodnota></div>\n";
    $spojeni->close();

    $cislo = date("U");
    
    
    //echo "<br> Rosný bod: ".$rbod."<br>";
    //echo "<br><div id=\"spodek\"><br>Zobrazeno: ".date("d. m. Y - H:i:s", $cislo);
    
?>
<br>
<popis>Grafy naměřených hodnot za posledních 24 hodin</popis>
<div id="grafik" class="graf"></div><br>
<div id="grafik2" style="width: 800px; height: 300px"></div><br>
<div id="grafik1" style="width: 800px; height: 300px"></div>
</article>
<footer><br>Vytvořil &copy;Josef Němec 2019</footer>
</center>
</body>
</html>