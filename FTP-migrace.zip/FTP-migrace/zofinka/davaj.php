<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
    <title>IoT meteostanice Žofinka</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 </head>
<body>
<?
    $teplota=$_GET["teplota"];
    $tlak=$_GET["tlak"];
    $vlhkost=$_GET["vlhkost"];
    $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
    if ($spojeni->connect_errno) {
        echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
        exit();
    }
    $cas=date("U");
    mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
    $d_zadani = "INSERT INTO Teplota (teplota, tlak, vlhkost, cas) VALUES (".$teplota.",".$tlak.",".$vlhkost.",".$cas.")";
    echo $d_zadani;
    $vysledek = $spojeni->query($d_zadani);
    $spojeni->close();
    //echo "<br><center>Žofinka říká že teplota je: ".$teplota." °C a tlak je: ".$tlak." hPa</center></br>"
    $fw=fopen("table2.dat", "a");
       if($teplota!=-127) {
           $dat=date("d-m-Y",$cas);
           $tim=date("H:i", $cas);
           fputcsv($fw, array($dat,$tim,$teplota,$tlak,$vlhkost));
       }
   fclose($fw);
?>
</body>
</html>