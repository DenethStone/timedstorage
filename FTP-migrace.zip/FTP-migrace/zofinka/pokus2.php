<?
 $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
 if ($spojeni->connect_errno) {
     echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
     exit();
 }

  mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
  $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));
  $fw=fopen("table2.dat", "w");
  fputcsv($fw, array("Date", "Time", "Temp", "Press", "Hum"));
  for($id=0; $id<$pocet+1; $id++){
     $d_zadani = "SELECT * FROM Teplota WHERE id=".$id;
     $vysledek = $spojeni->query($d_zadani);
     $vypis = mysqli_fetch_assoc($vysledek);
    
     if((int)$vypis["teplota"]!=-127) {
         $dat=date("d-m-Y",$vypis["cas"]);
         $tim=date("H:i", $vypis["cas"]);
         fputcsv($fw, array($dat,$tim,$vypis["teplota"],$vypis["tlak"],$vypis["vlhkost"]));
      
         //fpritf($fw,"%s, %s, %s\n",date("H:i", $vypis["cas"]),$vypis["tlak"],$vypis["teplota"]); 
         //echo "['".date("H:i", $vypis["cas"])."',".$vypis["tlak"]."]"; 
         //if($id!=$pocet) echo ",\n";
     }
     $vysledek->free();
 }
 $spojeni->close();
 fclose($fw);
?>
