<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
    <title>IoT meteostanice Žofinka</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
    <!--
		body { background-image: URL('./images/w2.jpg');
			   background-attachment: fixed; } 
		FIELDSET { padding: 8px; }
		LEGEND { color: black;
				 padding-bottom: 6px; }
		.text { position: absolute;
				left: 120px; }
		.button { text-align: center;
				  margin: 8px; }
	
    </style>
</head>
<body>
<center><h1>Žofinka naměřila</h1></center>
<?
    $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
    if ($spojeni->connect_errno) {
        echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
        exit();
    }

    mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
    $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));

    for($id=1; $id<$pocet+1; $id++){
        $d_zadani = "SELECT * FROM Teplota WHERE id=".$id;
        $vysledek = $spojeni->query($d_zadani);
        $vypis = mysqli_fetch_assoc($vysledek);
        echo $vypis["teplota"]." °C | ".date("d. m. Y - H:i:s", $vypis["cas"])."<br>\n";
        $vysledek->free();
    }
    $spojeni->close();
    $cislo = date("U");
    echo "<br>Zobrazeno: ".date("d. m. Y - H:i:s", $cislo);
?>
</body>
</html>