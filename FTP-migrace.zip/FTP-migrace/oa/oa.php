<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
    <title>IoT meteostanice Žofinka</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
    <!--
		body { background-image: URL('./images/w2.jpg');
			   background-attachment: fixed; } 
		FIELDSET { padding: 8px; }
		LEGEND { color: black;
				 padding-bottom: 6px; }
		.text { position: absolute;
				left: 120px; }
		.button { text-align: center;
				  margin: 8px; }
	
    </style>
</head>
<body>
<?
    $pokus=file_get_contents('http://dpmaster.deathmask.net/?game=openarena&server=151.236.222.109:27966', false);
    echo $pokus;

?>
</body>
</html>