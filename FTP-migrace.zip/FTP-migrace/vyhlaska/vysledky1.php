<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
  <link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
	<link rel="stylesheet" href="styl.css" type="text/css" />
	<title>Vyhláška 50 / 1978 Sb.</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<header>
		<div id="logo">
				<la>Vyhláška 50/1978 Sb.</la>
				<lb>SOŠ a SOU Lanškroun</lb>
		</div>
		<nav>
            <ul>
                <li>
                    <?php
                        echo " Připojen z IP: ".$_SERVER["REMOTE_ADDR"];
                    ?>
                </li>
            </ul>
        </nav>
        <div id="pravy">
            <?
                echo "Odesláno: ".date("H:i - d.m.Y");
                
            ?>
		</div>
</header>
<center>
<article align="left">
<br><br><br>
<p align="left">
<center>
    <h1>Výsledky testu byly uloženy.</h1><br>
</center>
<FIELDSET><LEGEND><b><font color="yellow">Informace</font></b></LEGEND>
<?php
    $OtazkyMAX=60;
    $t_start=strtotime($_GET["cas"]);
    $t_stop=strtotime(date("H:i"));
    $jmeno=$_GET["name"];

    echo "Jméno a příjmení: ".$jmeno."<br>\n";
    echo "Doba testu: ".date("H:i - d.m.Y", $t_start)." - ".date("H:i - d.m.Y", $t_stop)."<br>\n";
    echo "Celkem: ".(($t_stop-$t_start)/60)."<br>\n";
    echo "Digitální stopa: ".$_SERVER["HTTP_USER_AGENT"]."<br>\n";
       
    $odpoved=0;
    for ($i=0, $n=0; $i < $OtazkyMAX; $i++) {
        $ziskanyget = $_GET["Odpoved".$i];
        $odkaz = $odkaz."Odpoved".$i."=".$ziskanyget."&";
        list($uspel, $otazka) = Explode(".",$ziskanyget);
        if ($ziskanyget==""||$uspel==0) {
            $chyby[$n]=$otazka;		
            $n++;
        }
        if ($ziskanyget=="") $odpoved++; 
    }

    $spravne=60-Count($chyby);
    echo "<br>Počet bodů: ".$spravne."<br><br>\n";
    echo "<center><h1>";
    if ($spravne<=55) {
        echo "Neuspěl<br>\n";
    } else {
        echo "Uspěl<br>\n";
    }
    echo "</h1></center>\n";
    //echo "Záznam: ".$odkaz."<br>\n";
?>
</FIELDSET><BR>
</p>
<br>
</article>
<footer align="center"><br><br>Frontend and backend &copy;Josef Němec 2020</footer>
</center>
</body>
</html>