<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
  <link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
	<link rel="stylesheet" href="styl.css" type="text/css" />
	<title>Vyhláška 50 / 1978 Sb.</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<header>
		<div id="logo">
				<la>Vyhláška 50/1978 Sb.</la>
				<lb>SOŠ a SOU Lanškroun</lb>
		</div>
		<nav>
            <ul>
                <li>
                    <?php
                        echo " Připojen z IP: ".$_SERVER["REMOTE_ADDR"];
                    ?>
                </li>
            </ul>
        </nav>
        <div id="pravy">
            <?php
                echo "Spuštěno: ".date("H:i - d.m.Y");
                
            ?>
		</div>
</header>
<center>
<article align="left">
<br><br><br>
<p align="left">
<form action="administrace.php" method=POST>
<?php
    $SESSION="false";
    $SESSION=$_POST["sezeni"];
    if(($_POST["heslo"]!="krtek")||($SESSION!="true")) {
        echo "<center><h1>Přihlášení selhalo!</h1></center><br>";
    } else {
        echo "<FIELDSET><LEGEND><b><font color=\"blue\">Vyhledávání podle klíčového slova</font></b></LEGEND>\n";
        echo " Najdi: &nbsp; <input type=\"text\" name=\"slovo\" required minlength=\"3\" maxlength=\"20\" size=\"20\"><br><br><br>\n";
        echo "<input type=radio name=\"najdi\" value=\"1\">Vyhledat podle IP adresy<br>\n";
        echo "<input type=radio name=\"najdi\" value=\"2\">Vyhledat podle jména<br>\n";
        echo "</FIELDSET><BR>\n";
        echo "<table><tr><td><input type=checkbox name=\"cas\" value=\"".date("H:i")."\" checked style=\"display:none;\"><td></table><br>\n";
        echo "<table><tr><td><input type=checkbox name=\"sezeni\" value=\"true\" checked style=\"display:none;\"><td></table><br>\n";
	    echo "</p>";
        echo "<DIV class=buttonek align=\"center\">";
        echo "<BUTTON type=SUBMIT class=\"button button2\">VYHLEDAT</BUTTON>";
        echo "</DIV>";
    }
?>
</form>
<br>
</article>
<footer align="center"><br><br>Frontend and backend &copy;Josef Němec 2020</footer>
</center>
</body>
</html>