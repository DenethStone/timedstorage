<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
  <link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
	<link rel="stylesheet" href="styl.css" type="text/css" />
	<title>Vyhláška 50 / 1978 Sb.</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<header>
		<div id="logo">
				<la>Vyhláška 50/1978 Sb.</la>
				<lb>SOŠ a SOU Lanškroun</lb>
		</div>
		<nav>
            <ul>
                <li>
                    <?php
                        echo " Připojen z IP: ".$_SERVER["REMOTE_ADDR"];
                    ?>
                </li>
            </ul>
        </nav>
        <div id="pravy">
            <?php
                echo "Spuštěno: ".date("H:i - d.m.Y");
                
            ?>
		</div>
</header>
<center>
<article align="left">
<br><br><br>
<p align="left">
<FIELDSET><LEGEND><b><font color="blue">Výsledky</font></b></LEGEND>
<form action="administrace.php" method=POST>
<table table border="1" cellpadding="6" cellspacing="0">
<thead style="background-color: lightblue">
    <th style="width: 200px">Jméno a příjmení</th>
    <th style="width: 100px">Čas [min]</th>
    <th style="width: 100px">Počet bodů</th>
    <th style="width: 100px">Ukazatel</th>
</thead>
<?php
    $SESSION="false";
    $SESSION=$_POST["sezeni"];
    if(($_POST["heslo"]!="krtek")||($SESSION!="true")) {
        echo "<center><h1>Přihlášení selhalo!</h1></center><br>";
    } else {
        $spojeni = new mysqli("localhost", "vyhlaska", "0wxU6t[!70l45uGr", "vyhlaska");
        if ($spojeni->connect_errno) {
            echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
            exit();
        }
        mysqli_set_charset($spojeni,"utf8");
        $vysledek = $spojeni->query("SELECT * FROM vysledky");
        while ($uzivatel = $vysledek->fetch_assoc()){
           $odkaz="<a href=\"./chyby.php?".$uzivatel['Odkaz']."\">ukázat</a>";
           echo "<tr style=\"border: 1px solid blue;\"><td>".$uzivatel['Jmeno']." ".$uzivatel['Prijmeni']."</td><td style=\"text-align: center\">".(($uzivatel['tStop']-$uzivatel['tStart'])/60)."</td><td style=\"text-align: center\">".$uzivatel['Body']."</td><td style=\"text-align: center\">".$odkaz."</td><tr>";
        }
        $spojeni->close();
        echo "</table><br>";
    }
?>
</form>
</FIELDSET><BR>
<br>
</article>
<footer align="center"><br><br>Frontend and backend &copy;Josef Němec 2020</footer>
</center>
</body>
</html>