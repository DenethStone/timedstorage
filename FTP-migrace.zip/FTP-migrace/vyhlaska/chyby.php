<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
  <link href='https://fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
	<link rel="stylesheet" href="styl.css" type="text/css" />
	<title>Vyhláška 50 / 1978 Sb.</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<header>
		<div id="logo">
				<la>Vyhláška 50/1978 Sb.</la>
				<lb>  Zkušební testy §5</lb>
		</div>
		
        <div id="pravy">
            <?php
                echo "Odesláno: ".date("H:i - d.m.Y"); 
            ?>
		</div>
</header>
<center>
<article align="left">
<br><br><br>
<p align="left">

<FIELDSET><LEGEND><b><font color="blue">Informace</font></b></LEGEND>
<?php
    $OtazkyMAX=60;
     
    $odpoved=0;
    for ($i=0, $n=0; $i < $OtazkyMAX; $i++) {
        $ziskanyget = $_GET["Odpoved".$i];
        $odkaz = $odkaz."Odpoved".$i."=".$ziskanyget."&";
        list($uspel, $otazka) = Explode(".",$ziskanyget);
        if ($ziskanyget==""||$uspel==0) {
            $chyby[$n]=$otazka;		
            $n++;
        }
        if ($ziskanyget=="") $odpoved++; 
    }

    $spravne=$OtazkyMAX-Count($chyby);
    echo "<b>Počet bodů: </b>".$spravne." z ".$OtazkyMAX."<br><br>\n";
    echo "</FIELDSET><BR>\n";
	$spravne=Count($chyby);
	if(($OtazkyMAX-$spravne)!=$OtazkyMAX) {
		echo "<center><h1>Chybně vyplněné otázky</h1><br></center>";
	}
	if(Count($chyby)!=0 && $odpoved==0) {
		$spojeni = new mysqli("localhost", "vyhlaska", "0wxU6t[!70l45uGr", "vyhlaska");
		if ($spojeni->connect_errno) {
	   		echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
       		exit();
    	}
    	mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
		for ($i=0; $i<Count($chyby); $i++) {
			//echo $chyby[$i]."<br>";
			$d_zadani = "SELECT * FROM otazky WHERE ID=$chyby[$i]";
       		$d_odpoved = "SELECT * FROM odpovedi WHERE ID=$chyby[$i]";
       		$vysledek = $spojeni->query($d_zadani);
			$vypis = mysqli_fetch_assoc($vysledek);
			echo "<FIELDSET><LEGEND><b><font color=\"blue\">".$vypis["Zadani"]."</font></b></LEGEND>\n";
			if ($vypis["Image"]=="1") echo "<img src=\"./images/img".$chyby[$i].".png\" align=\"right\">";
			$vysledek->free();
			$vysledek = $spojeni->query($d_odpoved);
       		$vypis = mysqli_fetch_assoc($vysledek);
			if ($vypis["Image"]=="1") echo "<img src=\"./images/".$vypis["odpoved1"]."\"><br>\n";
			else echo "<b><font color=\"black\">".$vypis["odpoved1"]."</b></font><br>\n";
			echo "</FIELDSET><BR>";
			$vysledek->free();
		}
		$spojeni->close();
	}
?>		
</p>
<br>
</article>
<footer align="center"><br><br>Frontend and backend &copy;Josef Němec 2020</footer>
</center>
</body>
</html>