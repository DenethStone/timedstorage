<html xmlns="http://www.w3.org/1999/xhtml"
    xml:lang="cs"
    lang="cs"
    dir="ltr">
<head>
    <title>IoT meteostanice Žofinka</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
    <!--
		body { background-image: URL('./rokmal/zofka.jpg');
			   background-attachment: fixed; } 
    #cedule {
   			width: 220px;
   			height: 150px;
   			margin : 10px 10px 10px 10px;
			  background: orange;
		  }
    #spodek {
      width: 400px;
      height: 80px;
      background: deeppink;
    }
		p {
			  margin : 10px 10px 10px 10px;
		  }
    </style>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Čas', 'Teplota ve °C'],
        <?
          $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
          if ($spojeni->connect_errno) {
            echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
            exit();
          }

         mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
         $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));

         for($id=1; $id<$pocet+1; $id++){
            $d_zadani = "SELECT * FROM Teplota WHERE id=".$id;
            $vysledek = $spojeni->query($d_zadani);
            $vypis = mysqli_fetch_assoc($vysledek);
            
            if((int)$vypis["teplota"]!=-127) { 
                echo "['".date("H:i", $vypis["cas"])."',".$vypis["teplota"]."]"; 
                if($id!=$pocet) echo ",\n";
            }
            $vysledek->free();
         }
         $spojeni->close();
         
         
        ?>
        ]);

        var options = {
          curveType: 'function',
          backgroundColor: {
            fill: '#FFFFFF',
            fillOpacity: 0.7
          },
          legend: { position: 'bottom' },
          lineWidth: 3,
          colors: [ '#b9c246', '#d3362d', '#e7711b',
                   '#e49307', '#e49307', '#e2431e' ],
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
</head>
<body>
<center>
<br>
    
<div id="cedule"><center><br>
<font face="arial" color="white" size="5">Žofinka změřila:</font><br>
<?
    $spojeni = new mysqli("wm149.wedos.net", "w168935_zofinka", "overridE80@", "d168935_zofinka");
    if ($spojeni->connect_errno) {
      echo ("Connect failed: ".$mysqli->connect_error."<br>\n");
      exit();
    }

    mysqli_set_charset($spojeni,"utf8"); //Volba znakove sady
    $pocet = mysqli_num_rows($spojeni->query("SELECT * FROM Teplota"));

    $d_zadani = "SELECT * FROM Teplota WHERE id=".$pocet;
    $vysledek = $spojeni->query($d_zadani);
    $vypis = mysqli_fetch_assoc($vysledek);

    echo "<font face=\"arial\" color=\"white\" size=\"15\">".$vypis["teplota"]." °C</font>\n";
    echo "<font face=\"arial\" color=\"white\" size=\"5\"> Dnes v ".date("H:i", $vypis["cas"])."\n";
    echo "</center></div><br>\n";
    $spojeni->close();

    $cislo = date("U");
   
    echo "<div id=\"curve_chart\" style=\"width: 900px; height: 250px\"></div>";
    echo "<br><div id=\"spodek\"><br>Zobrazeno: ".date("d. m. Y - H:i:s", $cislo);
    
?></div>
</center>
</body>
</html>